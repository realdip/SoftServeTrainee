import unittest
from sys import path

path.append('../')
print(path)
from numbers import Numbers as Num


class TestNumbers(unittest.TestCase):
    def test_validation(self):
        self.assertEqual(Num.validation(1), 1)
        self.assertEqual(Num.validation(1.0), 1)
        self.assertEqual(Num.validation(-1), 1)

        self.assertRaises(TypeError, Num.validation, '1', 0)
        self.assertRaises(TypeError, Num.validation, [], 0)

    def test_sequence(self):
        self.assertEqual(Num.sequence(1), [0, 1])
        self.assertEqual(Num.sequence(4), [0, 1, 2])
        self.assertEqual(Num.sequence(30), [0, 1, 2, 3, 4, 5])
        self.assertEqual(Num.sequence(81), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
        self.assertEqual(Num.sequence(100), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        self.assertEqual(Num.sequence(121), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11])


if __name__ == '__main__':
    unittest.main()
