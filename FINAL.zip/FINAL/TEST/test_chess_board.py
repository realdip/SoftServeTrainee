import unittest
from sys import path
path.append('../')
from chessboard import chess_input_validator


class TestChessBoard(unittest.TestCase):
    def test_validation(self):
        self.assertEqual(chess_input_validator('4', '5'), (4, 5))
        self.assertEqual(chess_input_validator('1', '8'), (1, 8))



if __name__ == '__main__':
    unittest.main()