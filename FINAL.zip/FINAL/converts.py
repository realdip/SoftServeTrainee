OUTPUT_TEXT = (
    'Height of letter #1: ',
    'Width of letter #1: ',
    'Height of letter #2: ',
    'Width of letter #2: '
)


class Letter:
    def __init__(self, h1=0, w1=0, h2=0, w2=0):
        self.h1 = h1
        self.w1 = w1
        self.h2 = h2
        self.w2 = w2

    def check(self, h1, w1, h2, w2):
        if max(h1, w1) < max(h2, w2) and min(h1, w1) < min(h2, w2):
            return "First letter {}х{} can be put in letter {}х{}".format(h1, w1, h2, w2)
        elif max(h1, w1) > max(h2, w2) and min(h1, w1) > min(h2, w2):
            return "Second letter {}х{} can be put in {}х{}".format(h2, w2, h1, w1)
        else:
            return "None of letters can be put in another"

    def text_to_float(self, text):
        try:
            text = text.replace(',', '.').replace(' ', '')
            number = float(text)
        except ValueError:
            print('{} is incorrect'.format(text))
            return text
        return number

    def start(self):
        measures = []

        while len(measures) < 4:
            text = input(OUTPUT_TEXT[len(measures)])
            text = self.text_to_float(text)
            if type(text) == float:
                measures.append(text)

        self.h1, self.w1, self.h2, self.w2 = measures
        print(self.check(self.h1, self.w1, self.h2, self.w2))

        n = input("Would you like to continue? Enter 'y' or 'yes' :\n").lower()
        if n in ('yes', 'y'):
            self.start()


if __name__ == "__main__":
    obj = Letter()
    obj.start()
