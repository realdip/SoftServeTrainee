

class Triangle:
    def __init__(self, name, sides, area):
        self.name = name
        self.sides = sides
        self.area = area

    def __str__(self):
        return "[{}]: {} cm²".format(self.name, self.area)

    def triangle_area(sides):
        a, b, c = sides
        p = (a + b + c) / 2
        if p <= a or p <= b or p <= c:
            return None
        area = ((p - a) * (p - b) * (p - c)) ** 0.5
        return round(area, 2)

    def create():
        name = input("Name: ")
        valid_sides = None
        while not valid_sides:
            sides = input("Sides: ").replace(' ', '').split(',')
            try:
                a, b, c = sides
                sides = (abs(float(a)), abs(float(b)), abs(float(c)))
            except ValueError:
                print('Incorrect:', sides)
            except TypeError:
                print('Incorrect:', sides)
            if len(sides) == 3:
                area = Triangle.triangle_area(sides)
                if area:
                    valid_sides = True
                    return Triangle(name, sides, area)
                else:
                    print('Input error:', sides)
                    print('Triangle with these sides does not exist')
            else:
                print("Count of sides must be 3")


def start():
    new_triangles = []
    repeat = True
    while repeat:
        new_triangles.append(Triangle.create())
        answer = input("Print 'y' or 'yes' to continue: ").lower()
        if answer not in ('yes', 'y'):  # or just press ENTER
            repeat = None

    print('\nSorted:')
    i = 1
    for self in sorted(new_triangles, key=lambda x: x.area):
        print('{}. [Triangle {}]: {} сm²'.format(i, self.name, self.area))
        i += 1


if __name__ == "__main__":
    start()
