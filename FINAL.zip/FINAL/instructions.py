TEXT = {
	'chesstext': 'Prigram will build chessboard by entered measures\
	\nPlease, enter measures.',}